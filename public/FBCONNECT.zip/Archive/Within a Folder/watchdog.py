#!/usr/bin/env python3
"""
Watchdog script for Email to Facebook Forwarder
Monitors the main process and restarts it if it dies
"""

import os
import sys
import time
import subprocess
import logging
import psutil
from datetime import datetime
import signal

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - WATCHDOG - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("watchdog.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ForwarderWatchdog:
    def __init__(self):
        self.process = None
        self.restart_count = 0
        self.max_restarts_per_hour = 10
        self.restart_times = []
        self.running = True
        
    def is_forwarder_running(self):
        """Check if the forwarder process is running"""
        try:
            # Check if lock file exists and process is actually running
            lock_file = "email_fb_forwarder.lock"
            if os.path.exists(lock_file):
                with open(lock_file, 'r') as f:
                    pid = int(f.read().strip())
                
                # Check if process with this PID exists
                if psutil.pid_exists(pid):
                    try:
                        proc = psutil.Process(pid)
                        # Check if it's actually our script
                        cmdline = ' '.join(proc.cmdline())
                        if 'email_fb_forwarder.py' in cmdline:
                            return True
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                
                # Lock file exists but process doesn't - clean up stale lock
                logger.warning("Removing stale lock file")
                os.remove(lock_file)
            
            return False
            
        except Exception as e:
            logger.error(f"Error checking forwarder status: {e}")
            return False
    
    def can_restart(self):
        """Check if we can restart (rate limiting)"""
        now = datetime.now()
        # Remove restart times older than 1 hour
        self.restart_times = [t for t in self.restart_times if (now - t).seconds < 3600]
        
        if len(self.restart_times) >= self.max_restarts_per_hour:
            logger.error(f"Too many restarts in the last hour ({len(self.restart_times)})")
            return False
        
        return True
    
    def start_forwarder(self):
        """Start the forwarder process"""
        try:
            if not self.can_restart():
                return False
            
            logger.info("Starting Email to Facebook Forwarder...")
            
            # Start in silent mode
            cmd = [sys.executable, "email_fb_forwarder.py", "--silent"]
            
            # Use subprocess.Popen to start detached process
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            
            self.restart_count += 1
            self.restart_times.append(datetime.now())
            
            logger.info(f"Forwarder started with PID {self.process.pid} (restart #{self.restart_count})")
            
            # Wait a moment to see if it starts successfully
            time.sleep(5)
            
            if self.process.poll() is None:  # Process is still running
                logger.info("Forwarder started successfully")
                return True
            else:
                logger.error("Forwarder failed to start")
                return False
                
        except Exception as e:
            logger.error(f"Error starting forwarder: {e}")
            return False
    
    def stop_forwarder(self):
        """Stop the forwarder process"""
        try:
            if self.process and self.process.poll() is None:
                logger.info("Stopping forwarder process...")
                self.process.terminate()
                
                # Wait for graceful shutdown
                try:
                    self.process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    logger.warning("Forwarder didn't stop gracefully, killing...")
                    self.process.kill()
                    self.process.wait()
                
                logger.info("Forwarder stopped")
            
        except Exception as e:
            logger.error(f"Error stopping forwarder: {e}")
    
    def monitor(self):
        """Main monitoring loop"""
        logger.info("Watchdog started - monitoring Email to Facebook Forwarder")
        
        # Start the forwarder initially
        if not self.is_forwarder_running():
            self.start_forwarder()
        else:
            logger.info("Forwarder is already running")
        
        try:
            while self.running:
                time.sleep(30)  # Check every 30 seconds
                
                if not self.is_forwarder_running():
                    logger.warning("Forwarder is not running - attempting restart")
                    if self.start_forwarder():
                        logger.info("Forwarder restarted successfully")
                    else:
                        logger.error("Failed to restart forwarder")
                        # Wait longer before trying again
                        time.sleep(300)  # 5 minutes
                else:
                    # Forwarder is running - log periodic status
                    if self.restart_count > 0 and (datetime.now().minute % 15 == 0):
                        logger.info(f"Watchdog status: Forwarder running (total restarts: {self.restart_count})")
                
        except KeyboardInterrupt:
            logger.info("Watchdog stopped by user")
        except Exception as e:
            logger.error(f"Unexpected error in watchdog: {e}")
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Cleanup on shutdown"""
        logger.info("Watchdog shutting down...")
        self.running = False
        # Note: We don't stop the forwarder on watchdog shutdown
        # The forwarder should continue running independently

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info(f"Watchdog received signal {signum}, shutting down...")
    sys.exit(0)

if __name__ == "__main__":
    # Set up signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    watchdog = ForwarderWatchdog()
    watchdog.monitor() 