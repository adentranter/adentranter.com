import imaplib
import email
import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, SessionNotCreatedException
from dotenv import load_dotenv
import logging
from selenium.webdriver.common.keys import Keys
import tempfile
from pathlib import Path
import platform
import subprocess
import sys
import argparse
import threading
import mimetypes
import base64
import urllib.parse
import signal
import atexit
import psutil
from datetime import datetime, timedelta

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("forwarder.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Try to import system tray dependencies
try:
    import pystray
    from PIL import Image, ImageDraw
    TRAY_AVAILABLE = True
except ImportError:
    TRAY_AVAILABLE = False
    logger.warning("pystray not available - system tray functionality disabled")

# Helper to fetch environment variables interactively if missing
def _require_env(var_name: str, prompt: str) -> str:
    """Return environment variable or ask user to input value."""
    val = os.getenv(var_name)
    if not val:
        # Ensure the console is visible for input
        try:
            val = input(f"{prompt} ({var_name}): ").strip()
        except EOFError:
            raise RuntimeError(f"Environment variable {var_name} is required but could not prompt for input.")
        if not val:
            raise RuntimeError(f"{var_name} is required.")
        os.environ[var_name] = val  # set for remainder of runtime
        # Persist to .env so we don't ask again next time
        try:
            env_path = Path('.env')
            # Append or create .env silently
            with env_path.open('a', encoding='utf-8') as fh:
                fh.write(f"\n{var_name}={val}")
            logger.info(f"Saved {var_name} to .env for future runs")
        except Exception as e:
            logger.warning(f"Could not save {var_name} to .env: {e}")
    return val

class EmailToFacebookForwarder:
    def __init__(self, silent_mode=False):
        # Mode settings
        self.silent_mode = silent_mode
        
        # Email configuration (interactive fallback)
        self.email_user = _require_env('EMAIL_USER', 'IMAP username/email address')
        self.email_password = _require_env('EMAIL_PASSWORD', 'IMAP password (use app password for Gmail)')
        self.email_host = _require_env('EMAIL_HOST', 'IMAP server (e.g. imap.gmail.com, imap.zoho.com)')
        email_port_str = _require_env('EMAIL_PORT', 'IMAP port (usually 993 for SSL)')
        try:
            self.email_port = int(email_port_str)
        except ValueError:
            logger.error(f"Invalid port number: {email_port_str}")
            self.email_port = 993  # Default fallback
        
        # Facebook/Messenger configuration (interactive fallback)
        self.fb_email = _require_env('FACEBOOK_EMAIL', 'Facebook login email')
        self.fb_password = _require_env('FACEBOOK_PASSWORD', 'Facebook password / app-password')
        # This can be a Facebook group URL OR a Messenger thread URL.
        self.fb_group_url = _require_env('FACEBOOK_GROUP_URL', 'Facebook Group or Messenger URL')
        
        # Browser setup
        self.driver = None
        self.is_logged_in = False
        
        # Email tracking
        self.last_email_count = 0
        
        # System tray
        self.tray_icon = None
        self.running = True
        
        # Health monitoring
        self.last_successful_check = datetime.now()
        self.consecutive_failures = 0
        self.max_consecutive_failures = 5
        self.health_check_interval = 60  # seconds
        self.restart_attempts = 0
        self.max_restart_attempts = 10
        
    def setup_browser(self):
        """Initialize Chrome browser with persistent session"""
        try:
            logger.info("=== SETUP BROWSER START ===")
            
            # Kill any existing Chrome processes that might be using our profile
            _kill_existing_chrome()
            time.sleep(2)  # Give time for processes to terminate
            
            # Ensure our profile directory exists
            profile_dir = os.path.join(os.getcwd(), "facebook-session")
            os.makedirs(profile_dir, exist_ok=True)
            logger.info(f"Using profile directory: {profile_dir}")
            
            # Basic Chrome options
            chrome_options = Options()
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--log-level=3")
            chrome_options.add_argument("--remote-debugging-port=0")  # Fix DevTools port issue
            
            # Additional options to prevent restore popup
            chrome_options.add_argument("--disable-session-crashed-bubble")
            chrome_options.add_argument("--disable-restore-session-state")
            chrome_options.add_argument("--disable-features=TranslateUI")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-plugins")
            chrome_options.add_argument("--disable-background-timer-throttling")
            chrome_options.add_argument("--disable-backgrounding-occluded-windows")
            chrome_options.add_argument("--disable-renderer-backgrounding")
            
            # Add headless mode if running silently
            if hasattr(self, 'silent_mode') and self.silent_mode:
                chrome_options.add_argument("--headless")
                logger.info("Running Chrome in headless mode")
            
            # Use a dedicated Chrome profile for this app (fresh but persistent)
            profile_dir = os.path.join(os.getcwd(), "facebook-session")
            chrome_options.add_argument(f"--user-data-dir={profile_dir}")
            chrome_options.add_argument("--profile-directory=Default")
            # Disable the "Restore Pages" popup
            chrome_options.add_argument("--disable-session-crashed-bubble")
            chrome_options.add_argument("--disable-restore-session-state")
            logger.info(f"Using dedicated Chrome profile: {profile_dir}")
            
            # Use chromedriver from current directory or PATH
            driver_path = os.getenv("CHROMEDRIVER_PATH", "chromedriver.exe")
            logger.info(f"Using chromedriver at: {driver_path}")
            
            service = Service(driver_path)
            logger.info("Service created")
            
            # Try to launch Chrome
            logger.info("Attempting to launch Chrome...")
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            logger.info("Chrome launched successfully!")
            
            # Test that it's working
            logger.info("Testing browser by navigating to Google...")
            self.driver.get("https://www.google.com")
            logger.info(f"Current URL: {self.driver.current_url}")
            
            # Handle restore pages popup with aggressive approach
            if self._force_handle_restore_popup():
                logger.info("Restore popup handled during browser setup")
            
            logger.info("=== SETUP BROWSER COMPLETE ===")
            return True
            
        except Exception as e:
            logger.error(f"=== SETUP BROWSER FAILED ===")
            logger.exception("Failed to setup browser")
            return False
    
    def _handle_restore_pages_popup(self):
        """Handle the 'Restore Pages' popup if it appears"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            logger.info("Checking for restore pages popup...")
            
            # Look for the restore pages popup and click "Don't Restore"
            restore_selectors = [
                "button[data-testid='restore-pages-dont-restore']",
                "button:contains('Don't Restore')",
                "[aria-label='Don't Restore']",
                "button[jsaction*='restore']",
                "button[aria-label*='Don't restore']",
                "button[data-testid*='dont-restore']",
                "button[jsaction*='dont-restore']",
                # More generic selectors for restore-related buttons
                "button:contains('Restore')",
                "button[aria-label*='Restore']",
                "button[data-testid*='restore']"
            ]
            
            for selector in restore_selectors:
                try:
                    # Try to find the button with a shorter timeout
                    button = WebDriverWait(self.driver, 2).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    logger.info(f"Found restore popup button with selector: {selector}")
                    button.click()
                    logger.info("Clicked 'Don't Restore' on popup")
                    time.sleep(2)  # Give it time to process
                    return True
                except TimeoutException:
                    continue
            
            # Also try to find any dialog or popup that might be blocking
            try:
                # Look for any dialog that might be the restore popup
                dialogs = self.driver.find_elements(By.CSS_SELECTOR, "[role='dialog'], .modal, .popup, [data-testid*='dialog']")
                for dialog in dialogs:
                    # Look for buttons within the dialog
                    buttons = dialog.find_elements(By.CSS_SELECTOR, "button")
                    for button in buttons:
                        button_text = button.text.lower()
                        if any(word in button_text for word in ['restore', 'dont', "don't", 'cancel', 'close']):
                            logger.info(f"Found potential restore dialog button: {button_text}")
                            button.click()
                            time.sleep(2)
                            return True
            except Exception as e:
                logger.debug(f"Error checking for dialogs: {e}")
            
            # If no popup found, that's fine
            logger.info("No restore popup found")
            return False
            
        except Exception as e:
            logger.warning(f"Error handling restore popup: {e}")
            return False
    
    def _force_handle_restore_popup(self):
        """More aggressive approach to handle restore popup - tries multiple strategies"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            logger.info("Attempting aggressive restore popup handling...")
            
            # Strategy 1: Try the normal method
            if self._handle_restore_pages_popup():
                return True
            
            # Strategy 2: Try pressing Escape key
            try:
                from selenium.webdriver.common.keys import Keys
                self.driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
                logger.info("Pressed Escape key to dismiss popup")
                time.sleep(1)
                return True
            except Exception as e:
                logger.debug(f"Escape key strategy failed: {e}")
            
            # Strategy 3: Try clicking outside the popup
            try:
                body = self.driver.find_element(By.TAG_NAME, "body")
                body.click()
                logger.info("Clicked outside popup to dismiss")
                time.sleep(1)
                return True
            except Exception as e:
                logger.debug(f"Click outside strategy failed: {e}")
            
            # Strategy 4: Try to find any visible button and click it
            try:
                buttons = self.driver.find_elements(By.CSS_SELECTOR, "button")
                for button in buttons:
                    if button.is_displayed() and button.is_enabled():
                        button_text = button.text.lower()
                        if any(word in button_text for word in ['restore', 'dont', "don't", 'cancel', 'close', 'no', 'skip']):
                            logger.info(f"Found and clicking button: {button_text}")
                            button.click()
                            time.sleep(2)
                            return True
            except Exception as e:
                logger.debug(f"Button search strategy failed: {e}")
            
            logger.info("Aggressive restore popup handling completed")
            return False
            
        except Exception as e:
            logger.warning(f"Error in aggressive restore popup handling: {e}")
            return False
    
    def _navigate_and_handle_popups(self, url, description="page"):
        """Navigate to a URL and handle any restore popups that appear"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            logger.info(f"Navigating to {description}: {url}")
            self.driver.get(url)
            time.sleep(3)
            
            # Handle any restore popup with aggressive approach
            popup_handled = self._force_handle_restore_popup()
            if popup_handled:
                logger.info(f"Restore popup handled after navigating to {description}")
                time.sleep(2)
                # If we handled a popup, the page might need to reload
                if self.driver.current_url != url:
                    logger.info(f"Retrying navigation to {description}...")
                    self.driver.get(url)
                    time.sleep(3)
                    # Handle popup again after retry
                    self._force_handle_restore_popup()
                    time.sleep(2)
            
            logger.info(f"Successfully navigated to {description}: {self.driver.current_url}")
            return True
            
        except Exception as e:
            logger.error(f"Error navigating to {description}: {e}")
            return False
    
    def login_to_facebook(self):
        """Login to Messenger directly using the Messenger login URL"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            logger.info("=== LOGIN TO MESSENGER START ===")

            # Build Messenger login URL
            messenger_login_url = f"https://www.messenger.com/login.php?next={self.fb_group_url}"
            logger.info(f"Navigating to Messenger login: {messenger_login_url}")
            self.driver.get(messenger_login_url)
            time.sleep(3)  # Give page time to load

            # Check if we're already logged in (redirected to the thread)
            current_url = self.driver.current_url
            logger.info(f"Current URL after navigation: {current_url}")
            
            # More specific check - we're only logged in if:
            # 1. We're at the actual thread URL (not just containing it)
            # 2. AND we're not on a login page
            if (self.fb_group_url in current_url and 
                "login" not in current_url.lower() and 
                "checkpoint" not in current_url.lower() and
                not self._is_on_login_page()):
                logger.info("Already logged in! Redirected directly to Messenger thread.")
                self.is_logged_in = True
                return True

            # Check if we're on a checkpoint or security page
            if "checkpoint" in current_url or "security" in current_url:
                logger.info("Detected security checkpoint. Please complete verification manually.")
                print("\n[INFO] Security checkpoint detected in browser.")
                print("[INFO] Please complete verification, then press Enter here to continue...")
                input()
                
                # After manual verification, navigate to thread
                self.driver.get(self.fb_group_url)
                time.sleep(3)
                
                if self.fb_group_url in self.driver.current_url:
                    logger.info("Successfully navigated to thread after checkpoint")
                    self.is_logged_in = True
                    return True

            # Look for login fields (only if we're on the login page)
            try:
                # Wait briefly to see if login fields appear
                email_field = WebDriverWait(self.driver, 5).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "#email"))
                )
                logger.info("Found login fields - proceeding with login")
                
                # Perform login
                self.driver.execute_script("arguments[0].scrollIntoView(true);", email_field)
                try:
                    email_field.clear()
                except Exception as e:
                    logger.warning(f"Could not clear email field: {e}")
                    try:
                        self.driver.execute_script("arguments[0].value = '';", email_field)
                    except Exception as e2:
                        logger.warning(f"Could not clear email field via JS: {e2}")
                try:
                    email_field.send_keys(self.fb_email)
                except Exception as e:
                    logger.error(f"Could not type email: {e}")
                    return False

                try:
                    pass_field = WebDriverWait(self.driver, 10).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, "#pass"))
                    )
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", pass_field)
                    try:
                        pass_field.clear()
                    except Exception as e:
                        logger.warning(f"Could not clear password field: {e}")
                        try:
                            self.driver.execute_script("arguments[0].value = '';", pass_field)
                        except Exception as e2:
                            logger.warning(f"Could not clear password field via JS: {e2}")
                    try:
                        pass_field.send_keys(self.fb_password)
                    except Exception as e:
                        logger.error(f"Could not type password: {e}")
                        return False
                    try:
                        pass_field.send_keys(Keys.ENTER)
                    except Exception as e:
                        logger.warning(f"Could not press Enter on password field: {e}")

                    # Prompt user to complete any 2FA or confirmation
                    print("\n[INFO] Please complete any 2FA, checkpoint, or confirmation in the browser window.")
                    print("[INFO] When you are fully logged in and see Messenger, press Enter here to continue...")
                    input()

                    # Wait for thread URL
                    logger.info(f"Waiting for Messenger thread URL: {self.fb_group_url}")
                    WebDriverWait(self.driver, 30).until(lambda d: self.fb_group_url in d.current_url)
                    logger.info("Messenger login and thread navigation successful!")
                    self.is_logged_in = True
                    return True
                    
                except Exception as e:
                    logger.error(f"Could not find or interact with password field: {e}")
                    return False
                    
            except TimeoutException:
                # No login fields found - check if we're already at the destination
                current_url = self.driver.current_url
                logger.info(f"No login fields found. Current URL: {current_url}")
                
                # More robust check for being logged in
                if (self.fb_group_url in current_url and 
                    "login" not in current_url.lower() and 
                    "checkpoint" not in current_url.lower() and
                    not self._is_on_login_page()):
                    logger.info("No login fields found, but already at thread URL - assuming logged in")
                    self.is_logged_in = True
                    return True
                elif ("messenger.com" in current_url and 
                      "login" not in current_url.lower() and
                      not self._is_on_login_page()):
                    logger.info("On Messenger but not at thread - navigating to thread")
                    self.driver.get(self.fb_group_url)
                    time.sleep(3)
                    current_url_after = self.driver.current_url
                    if (self.fb_group_url in current_url_after and 
                        "login" not in current_url_after.lower() and
                        not self._is_on_login_page()):
                        logger.info("Successfully navigated to thread")
                        self.is_logged_in = True
                        return True
                    else:
                        logger.error(f"Failed to navigate to thread or still on login page. URL: {current_url_after}")
                        return False
                else:
                    logger.error(f"Still on login page or unexpected page state. Current URL: {current_url}")
                    return False
                    
        except Exception as e:
            logger.error("=== LOGIN TO MESSENGER FAILED ===")
            logger.exception("Error during Messenger login")
            self.is_logged_in = False
            return False
    
    def _is_on_login_page(self):
        """Check if we're currently on a login page by looking for login elements"""
        try:
            # Look for common login page elements
            login_indicators = [
                "#email",  # Facebook email field
                "#pass",   # Facebook password field
                "input[type='email']",  # Generic email input
                "input[type='password']",  # Generic password input
                "[data-testid='royal_email']",  # Facebook login email
                "[data-testid='royal_pass']"    # Facebook login password
            ]
            
            for selector in login_indicators:
                try:
                    element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    if element and element.is_displayed():
                        logger.info(f"Login page detected - found element: {selector}")
                        return True
                except:
                    continue
            
            # Check page title and URL for login indicators
            try:
                title = self.driver.title.lower()
                url = self.driver.current_url.lower()
                
                login_keywords = ["log in", "login", "sign in", "signin"]
                for keyword in login_keywords:
                    if keyword in title or keyword in url:
                        logger.info(f"Login page detected - found keyword '{keyword}' in title/URL")
                        return True
            except:
                pass
                
            return False
            
        except Exception as e:
            logger.warning(f"Error checking if on login page: {e}")
            return False
    
    def save_attachment(self, part):
        """Save email attachment to temp directory"""
        try:
            filename = part.get_filename()
            if not filename:
                return None
            
            # Sanitize filename
            filename = "".join(c for c in filename if c.isalnum() or c in (' ', '.', '_', '-')).rstrip()
            if not filename:
                return None
            
            # Accept ALL file types - no restrictions!
            content_type = part.get_content_type()
            logger.info(f"Processing attachment: {filename} ({content_type})")
            
            # Create temp directory if it doesn't exist
            temp_dir = os.path.join(tempfile.gettempdir(), "email_fb_attachments")
            os.makedirs(temp_dir, exist_ok=True)
            
            # Create unique filename to avoid conflicts
            import time
            timestamp = str(int(time.time()))
            name, ext = os.path.splitext(filename)
            unique_filename = f"{name}_{timestamp}{ext}"
            filepath = os.path.join(temp_dir, unique_filename)
            
            # Save file
            with open(filepath, 'wb') as f:
                payload = part.get_payload(decode=True)
                if payload:
                    f.write(payload)
                    file_size = len(payload)
                    logger.info(f"Saved attachment: {filename} -> {unique_filename} ({content_type}, {file_size} bytes)")
                else:
                    logger.warning(f"Empty payload for attachment: {filename}")
                    return None
            
            return {
                'filepath': filepath,
                'filename': filename,  # Keep original name for display
                'unique_filename': unique_filename,
                'content_type': content_type,
                'file_size': file_size if 'file_size' in locals() else 0
            }
            
        except Exception as e:
            logger.error(f"Error saving attachment: {e}")
            return None
    
    def save_inline_image(self, part, cid):
        """Save inline image (embedded in email body) to temp directory"""
        try:
            # Generate filename from Content-ID if no filename provided
            filename = part.get_filename()
            if not filename:
                # Use CID as base filename with appropriate extension
                content_type = part.get_content_type()
                ext_map = {
                    'image/jpeg': '.jpg',
                    'image/png': '.png',
                    'image/gif': '.gif',
                    'image/webp': '.webp',
                    'image/bmp': '.bmp',
                    'image/tiff': '.tiff'
                }
                ext = ext_map.get(content_type, '.img')
                # Clean CID for filename
                clean_cid = "".join(c for c in cid if c.isalnum() or c in ('-', '_'))[:50]
                filename = f"inline_image_{clean_cid}{ext}"
            
            # Sanitize filename
            filename = "".join(c for c in filename if c.isalnum() or c in (' ', '.', '_', '-')).rstrip()
            if not filename:
                import time
                filename = f"inline_image_{int(time.time())}.img"
            
            content_type = part.get_content_type()
            logger.info(f"Processing inline image: {filename} (CID: {cid}, {content_type})")
            
            # Create temp directory if it doesn't exist
            temp_dir = os.path.join(tempfile.gettempdir(), "email_fb_attachments")
            os.makedirs(temp_dir, exist_ok=True)
            
            # Create unique filename to avoid conflicts
            import time
            timestamp = str(int(time.time()))
            name, ext = os.path.splitext(filename)
            unique_filename = f"{name}_{timestamp}{ext}"
            filepath = os.path.join(temp_dir, unique_filename)
            
            # Save file
            with open(filepath, 'wb') as f:
                payload = part.get_payload(decode=True)
                if payload:
                    f.write(payload)
                    file_size = len(payload)
                    logger.info(f"Saved inline image: {filename} -> {unique_filename} (CID: {cid}, {file_size} bytes)")
                else:
                    logger.warning(f"Empty payload for inline image: {filename} (CID: {cid})")
                    return None
            
            return {
                'filepath': filepath,
                'filename': filename,
                'unique_filename': unique_filename,
                'content_type': content_type,
                'file_size': file_size,
                'cid': cid,
                'is_inline': True
            }
            
        except Exception as e:
            logger.error(f"Error saving inline image (CID: {cid}): {e}")
            return None
    
    def replace_cid_references(self, body, inline_images):
        """Replace [cid:...] references in email body with file names"""
        try:
            import re
            
            # Find all CID references in the body
            cid_pattern = r'\[cid:([^\]]+)\]'
            matches = re.findall(cid_pattern, body)
            
            for cid in matches:
                if cid in inline_images:
                    image_info = inline_images[cid]
                    # Replace the CID reference with a descriptive text
                    replacement = f"[IMAGE: {image_info['filename']}]"
                    body = body.replace(f"[cid:{cid}]", replacement)
                    logger.info(f"Replaced CID reference: [cid:{cid}] -> {replacement}")
                else:
                    logger.warning(f"CID reference found but image not extracted: [cid:{cid}]")
            
            return body
            
        except Exception as e:
            logger.error(f"Error replacing CID references: {e}")
            return body
    
    def send_to_facebook_group(self, email_subject, email_from, email_body, attachments=None):
        """Send message to a Messenger thread using robust selectors"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            if not self.is_logged_in:
                logger.error("Not logged in to Messenger")
                return False

            # Ensure we're on the correct thread URL
            if self.fb_group_url not in self.driver.current_url:
                self.driver.get(self.fb_group_url)
                WebDriverWait(self.driver, 20).until(lambda d: self.fb_group_url in d.current_url)

            # Find the message input field
            try:
                message_input = WebDriverWait(self.driver, 15).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, '[contenteditable="true"][aria-label="Message"]'))
                )
            except TimeoutException:
                # Fallback: any contenteditable=true
                message_input = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, '[contenteditable="true"]'))
                )

            # Prepare message content with Windows line breaks
            message =  f"From: {email_from}\r\n\r\n"
            message += f"Subject: {email_subject}\r\n\r\n"
            message += f"Content: {email_body[:500]}\r\n\r\n"
            if len(email_body) > 500:
                message += "[Message truncated]\r\n\r\n"
            
            # Send the text message first
            message_input.click()
            time.sleep(1)
            
            # Clear any existing content and send the message
            try:
                # Clear the input field first
                message_input.clear()
            except:
                # If clear doesn't work, try JavaScript
                try:
                    self.driver.execute_script("arguments[0].innerText = '';", message_input)
                except:
                    pass
            
            # Type the message using Shift+Enter for line breaks
            # Split message by line breaks and send each part with Shift+Enter
            lines = message.split('\r\n')
            for i, line in enumerate(lines):
                if line:  # Only send non-empty lines
                    message_input.send_keys(line)
                if i < len(lines) - 1:  # Don't add line break after last line
                    message_input.send_keys(Keys.SHIFT + Keys.ENTER)
            logger.debug("Sent message content with Shift+Enter line breaks")
            
            time.sleep(1)
            
            # Send the text message first
            message_input.send_keys(Keys.ENTER)
            logger.info(f"Sent text message for: {email_subject}")
            time.sleep(2)  # Wait for message to send
            
            # Now handle attachments separately (they'll appear underneath)
            if attachments:
                logger.info(f"Uploading {len(attachments)} attachments...")
                success = self.upload_attachments_separately(attachments)
                if success:
                    logger.info("All attachments uploaded successfully")
                else:
                    logger.warning("Some attachments failed to upload")
            
            # Cleanup attachments
            if attachments:
                self.cleanup_attachments(attachments)
            
            time.sleep(2)
            return True
        except Exception as e:
            logger.error(f"Error posting to Messenger thread: {e}")
            return False
    
    def upload_attachments(self, attachments):
        """Upload attachments to Messenger"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            success_count = 0
            
            for attachment in attachments:
                try:
                    # Look for file upload button/input - try multiple strategies
                    file_input = None
                    
                    # Strategy 1: Look for hidden file inputs
                    file_inputs = [
                        "input[type='file']",
                        "[data-testid='file-upload']",
                        "[aria-label*='attach']",
                        "[aria-label*='file']",
                        "input[accept]"  # Any input that accepts files
                    ]
                    
                    for selector in file_inputs:
                        try:
                            elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                            for element in elements:
                                if element.get_attribute('type') == 'file':
                                    file_input = element
                                    logger.debug(f"Found file input with selector: {selector}")
                                    break
                            if file_input:
                                break
                        except:
                            continue
                    
                    # Strategy 2: Try to find and click attach buttons first
                    if not file_input:
                        attach_buttons = [
                            "[aria-label*='Attach']",
                            "[data-testid*='attach']",
                            "button[aria-label*='file']",
                            "[aria-label*='photo']",
                            "[data-testid*='photo']",
                            "svg[aria-label*='attach']",
                            "button[aria-label*='Add']"
                        ]
                        
                        for selector in attach_buttons:
                            try:
                                buttons = self.driver.find_elements(By.CSS_SELECTOR, selector)
                                for button in buttons:
                                    if button.is_displayed() and button.is_enabled():
                                        button.click()
                                        time.sleep(2)  # Wait for file dialog
                                        # Try to find file input again
                                        file_input = self.driver.find_element(By.CSS_SELECTOR, "input[type='file']")
                                        logger.debug(f"Found file input after clicking: {selector}")
                                        break
                                if file_input:
                                    break
                            except:
                                continue
                    
                    if file_input:
                        file_input.send_keys(attachment['filepath'])
                        logger.info(f"Uploaded attachment: {attachment['filename']}")
                        success_count += 1
                        time.sleep(1)
                    else:
                        logger.warning(f"Could not find file upload for: {attachment['filename']}")
                        
                except Exception as e:
                    logger.error(f"Error uploading {attachment['filename']}: {e}")
            
            return success_count > 0
            
        except Exception as e:
            logger.error(f"Error in upload_attachments: {e}")
            return False
    
    def upload_attachments_separately(self, attachments):
        """Upload attachments one by one as separate messages (they appear underneath the text)"""
        try:
            assert self.driver is not None, "Chrome driver not initialised"
            success_count = 0
            
            for i, attachment in enumerate(attachments, 1):
                try:
                    logger.info(f"Uploading attachment {i}/{len(attachments)}: {attachment['filename']}")
                    
                    # Find the message input again (it might have changed after sending the text)
                    try:
                        message_input = WebDriverWait(self.driver, 10).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, '[contenteditable="true"][aria-label="Message"]'))
                        )
                    except TimeoutException:
                        # Fallback: any contenteditable=true
                        message_input = WebDriverWait(self.driver, 5).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, '[contenteditable="true"]'))
                        )
                    
                    # Click to focus the input
                    message_input.click()
                    time.sleep(1)
                    
                    # Look for file upload - try multiple strategies
                    file_uploaded = False
                    
                    # Strategy 1: Look for hidden file inputs
                    file_inputs = [
                        "input[type='file']",
                        "[data-testid='file-upload']",
                        "[aria-label*='attach']",
                        "[aria-label*='file']",
                        "input[accept]"
                    ]
                    
                    for selector in file_inputs:
                        try:
                            elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                            for element in elements:
                                if element.get_attribute('type') == 'file':
                                    element.send_keys(attachment['filepath'])
                                    logger.info(f"Uploaded via file input: {attachment['filename']}")
                                    file_uploaded = True
                                    break
                            if file_uploaded:
                                break
                        except:
                            continue
                    
                    # Strategy 2: Try attach buttons if file input not found
                    if not file_uploaded:
                        attach_buttons = [
                            "[aria-label*='Attach']",
                            "[data-testid*='attach']",
                            "button[aria-label*='file']",
                            "[aria-label*='photo']",
                            "[data-testid*='photo']",
                            "svg[aria-label*='attach']",
                            "button[aria-label*='Add']"
                        ]
                        
                        for selector in attach_buttons:
                            try:
                                buttons = self.driver.find_elements(By.CSS_SELECTOR, selector)
                                for button in buttons:
                                    if button.is_displayed() and button.is_enabled():
                                        button.click()
                                        time.sleep(2)
                                        # Try to find file input after clicking
                                        file_input = self.driver.find_element(By.CSS_SELECTOR, "input[type='file']")
                                        file_input.send_keys(attachment['filepath'])
                                        logger.info(f"Uploaded via attach button: {attachment['filename']}")
                                        file_uploaded = True
                                        break
                                if file_uploaded:
                                    break
                            except:
                                continue
                    
                    if file_uploaded:
                        success_count += 1
                        # Wait a moment for the file to process, then send
                        time.sleep(2)
                        
                        # Send this attachment (Enter key)
                        try:
                            message_input.send_keys(Keys.ENTER)
                            logger.info(f"Sent attachment: {attachment['filename']}")
                        except:
                            # Try clicking a send button if Enter doesn't work
                            try:
                                send_button = self.driver.find_element(By.CSS_SELECTOR, "[aria-label*='Send']")
                                send_button.click()
                                logger.info(f"Sent attachment via button: {attachment['filename']}")
                            except:
                                logger.warning(f"Could not send attachment: {attachment['filename']}")
                        
                        # Wait between attachments
                        time.sleep(2)
                    else:
                        logger.warning(f"Could not find file upload method for: {attachment['filename']}")
                        
                except Exception as e:
                    logger.error(f"Error uploading {attachment['filename']}: {e}")
            
            return success_count > 0
            
        except Exception as e:
            logger.error(f"Error in upload_attachments_separately: {e}")
            return False
    
    def cleanup_attachments(self, attachments):
        """Clean up temporary attachment files"""
        for attachment in attachments:
            try:
                if os.path.exists(attachment['filepath']):
                    os.remove(attachment['filepath'])
                    logger.debug(f"Cleaned up: {attachment['filename']}")
            except Exception as e:
                logger.warning(f"Could not cleanup {attachment['filename']}: {e}")
    
    def check_email(self):
        """Check for new emails with health monitoring"""
        try:
            # Connect to email server
            mail = imaplib.IMAP4_SSL(self.email_host, self.email_port)
            mail.login(self.email_user, self.email_password)
            mail.select('inbox')
            
            # Search for all emails
            result, data = mail.search(None, 'ALL')
            email_ids = data[0].split()
            current_count = len(email_ids)
            
            # Check if we have new emails
            if current_count > self.last_email_count:
                logger.info(f"Found {current_count - self.last_email_count} new emails")
                
                # Process new emails (get the latest ones)
                new_emails = email_ids[self.last_email_count:]
                
                for email_id in new_emails[-5:]:  # Process last 5 new emails max
                    try:
                        result, data = mail.fetch(email_id, '(RFC822)')
                        if not data or not data[0] or len(data[0]) < 2:
                            logger.warning(f"Invalid email data for ID {email_id}")
                            continue
                            
                        raw_email = data[0][1]
                        if not raw_email:
                            logger.warning(f"Empty email data for ID {email_id}")
                            continue
                            
                        # Ensure raw_email is bytes
                        if isinstance(raw_email, int):
                            logger.warning(f"Invalid email data type for ID {email_id}")
                            continue
                            
                        email_message = email.message_from_bytes(raw_email)
                        
                        # Extract email details
                        subject = email_message.get('Subject', '') or "No Subject"
                        from_addr = email_message.get('From', '') or "Unknown Sender"
                        
                        # Get email body and attachments (including inline images)
                        body = ""
                        attachments = []
                        inline_images = {}  # Map CID to file info
                        
                        if email_message.is_multipart():
                            for part in email_message.walk():
                                content_type = part.get_content_type()
                                content_disposition = str(part.get("Content-Disposition"))
                                content_id = part.get("Content-ID")
                                
                                # Get text body
                                if content_type == "text/plain" and "attachment" not in content_disposition:
                                    payload = part.get_payload(decode=True)
                                    if payload and isinstance(payload, bytes):
                                        body = payload.decode('utf-8', errors='ignore')
                                
                                # Handle regular attachments
                                elif "attachment" in content_disposition:
                                    attachment_info = self.save_attachment(part)
                                    if attachment_info:
                                        attachments.append(attachment_info)
                                
                                # Handle inline images (embedded in email body)
                                elif content_id and content_type.startswith('image/'):
                                    # Remove < > brackets from Content-ID
                                    cid = content_id.strip('<>')
                                    inline_image_info = self.save_inline_image(part, cid)
                                    if inline_image_info:
                                        inline_images[cid] = inline_image_info
                                        attachments.append(inline_image_info)  # Also add to attachments for upload
                        else:
                            payload = email_message.get_payload(decode=True)
                            if payload and isinstance(payload, bytes):
                                body = payload.decode('utf-8', errors='ignore')
                        
                        # Replace CID references in body with file names
                        if inline_images:
                            body = self.replace_cid_references(body, inline_images)
                        
                        # Send to Facebook with attachments
                        self.send_to_facebook_group(subject, from_addr, body, attachments)
                        time.sleep(2)  # Rate limiting
                        
                    except Exception as e:
                        logger.error(f"Error processing email {email_id}: {e}")
                        continue
                
                self.last_email_count = current_count
            
            mail.close()
            mail.logout()
            
            # Mark successful check
            self.last_successful_check = datetime.now()
            self.consecutive_failures = 0
            
        except Exception as e:
            logger.error(f"Error checking email: {e}")
            self.consecutive_failures += 1
            self.handle_failure(e)
    
    def handle_failure(self, error):
        """Handle failures and attempt recovery"""
        logger.error(f"Failure #{self.consecutive_failures}: {error}")
        
        if self.consecutive_failures >= self.max_consecutive_failures:
            logger.critical(f"Too many consecutive failures ({self.consecutive_failures}). Attempting restart...")
            self.attempt_restart()
    
    def attempt_restart(self):
        """Attempt to restart the browser and reconnect"""
        try:
            self.restart_attempts += 1
            logger.info(f"Restart attempt #{self.restart_attempts}")
            
            if self.restart_attempts > self.max_restart_attempts:
                logger.critical("Maximum restart attempts exceeded. Sending emergency notification...")
                self.send_emergency_notification()
                return False
            
            # Close existing browser
            if self.driver:
                try:
                    self.driver.quit()
                except:
                    pass
                self.driver = None
            
            # Kill Chrome processes
            _kill_existing_chrome()
            time.sleep(5)
            
            # Reset state
            self.is_logged_in = False
            self.consecutive_failures = 0
            
            # Restart browser and login
            if self.setup_browser():
                # Check if we need to login or if we're already logged in
                if not self.is_logged_in:
                    login_success = self.login_to_facebook()
                else:
                    # Test if existing login is still valid
                    login_success = self.test_browser_health()
                    if not login_success:
                        # Existing login invalid, try fresh login
                        login_success = self.login_to_facebook()
                
                if login_success:
                    logger.info("Restart successful!")
                    self.restart_attempts = 0  # Reset counter on success
                    
                    # Send restart notification
                    try:
                        restart_body = f"DAEMON RESTARTED\r\nRestart #{self.restart_attempts} successful at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\r\nReason: {self.consecutive_failures} consecutive failures"
                        self.send_to_facebook_group("Restart Notification", "DAEMON", restart_body)
                    except Exception as e:
                        logger.warning(f"Failed to send restart notification: {e}")
                    
                    return True
                else:
                    logger.error("Restart failed")
                    return False
            else:
                logger.error("Browser setup failed during restart")
                return False
                
        except Exception as e:
            logger.error(f"Error during restart: {e}")
            return False
    
    def send_emergency_notification(self):
        """Send emergency notification when all restart attempts fail"""
        try:
            emergency_body = f"🚨 EMERGENCY: DAEMON FAILED 🚨\r\nMax restart attempts ({self.max_restart_attempts}) exceeded\r\nLast successful check: {self.last_successful_check}\r\nRequires manual intervention!"
            
            # Try to send via existing connection first
            if self.driver and self.is_logged_in:
                self.send_to_facebook_group("EMERGENCY ALERT", "DAEMON", emergency_body)
            else:
                # Try emergency browser setup
                if self.setup_browser() and self.login_to_facebook():
                    self.send_to_facebook_group("EMERGENCY ALERT", "DAEMON", emergency_body)
                    
        except Exception as e:
            logger.critical(f"Failed to send emergency notification: {e}")
    
    def health_check(self):
        """Periodic health check"""
        try:
            now = datetime.now()
            time_since_last_check = now - self.last_successful_check
            
            if time_since_last_check > timedelta(minutes=10):  # No successful check in 10 minutes
                logger.warning(f"No successful email check in {time_since_last_check}")
                
                # Test browser health
                if not self.test_browser_health():
                    logger.error("Browser health check failed")
                    self.attempt_restart()
                    
                # Test email connection
                if not self.test_email_connection():
                    logger.error("Email connection test failed")
                    
        except Exception as e:
            logger.error(f"Health check error: {e}")
    
    def test_browser_health(self):
        """Test if browser is still responsive"""
        try:
            if not self.driver:
                return False
                
            # Try to get current URL
            current_url = self.driver.current_url
            logger.debug(f"Browser health check - current URL: {current_url}")
            
            # Check if we're still logged in to Messenger
            if "messenger.com" not in current_url:
                logger.warning("Not on Messenger - attempting to navigate")
                self.driver.get(self.fb_group_url)
                time.sleep(3)
                
                # Check if navigation was successful
                new_url = self.driver.current_url
                if self.fb_group_url in new_url:
                    logger.info("Successfully navigated back to Messenger thread")
                    self.is_logged_in = True
                elif "messenger.com" in new_url:
                    logger.info("On Messenger but not at thread - still logged in")
                    self.is_logged_in = True
                else:
                    logger.warning("Navigation failed - may need to re-login")
                    self.is_logged_in = False
                    return False
                
            return True
            
        except Exception as e:
            logger.error(f"Browser health test failed: {e}")
            return False
    
    def test_email_connection(self):
        """Test email server connection"""
        try:
            mail = imaplib.IMAP4_SSL(self.email_host, self.email_port)
            mail.login(self.email_user, self.email_password)
            mail.select('inbox')
            mail.close()
            mail.logout()
            return True
            
        except Exception as e:
            logger.error(f"Email connection test failed: {e}")
            return False
    
    def start_monitoring(self):
        """Start the email monitoring loop"""
        logger.info("Starting Email to Facebook forwarder...")
        
        # Setup browser and login
        if not self.setup_browser():
            return False
        
        if not self.login_to_facebook():
            return False
        
        # Check if this is a fresh session or existing session
        profile_dir = os.path.join(os.getcwd(), "facebook-session")
        session_files = os.listdir(profile_dir) if os.path.exists(profile_dir) else []
        is_fresh_session = len(session_files) < 5  # Rough heuristic for fresh session
        
        # Send a one-off startup message so that admins know the bot is alive
        try:
            session_type = "FRESH SESSION" if is_fresh_session else "EXISTING SESSION"
            startup_body = f"DAEMON INIT'd\r\n{session_type}\r\nMonitoring started at {time.strftime('%Y-%m-%d %H:%M:%S')}"
            self.send_to_facebook_group("Startup Notification", "DAEMON", startup_body)
        except Exception as e:
            logger.warning(f"Failed to post startup message: {e}")
        
        # Get initial email count
        try:
            mail = imaplib.IMAP4_SSL(self.email_host, self.email_port)
            mail.login(self.email_user, self.email_password)
            mail.select('inbox')
            result, data = mail.search(None, 'ALL')
            self.last_email_count = len(data[0].split())
            mail.close()
            mail.logout()
            logger.info(f"Starting with {self.last_email_count} emails in inbox")
        except Exception as e:
            logger.error(f"Error getting initial email count: {e}")
            return False
        
                # Start monitoring loop
        if self.silent_mode and TRAY_AVAILABLE:
            logger.info("Starting in silent mode with system tray")
            self.start_system_tray()
        else:
            logger.info("Monitoring started. Press Ctrl+C to stop.")
            
            # Start health check thread
            health_thread = threading.Thread(target=self.health_monitor_loop, daemon=True)
            health_thread.start()
            
            try:
                while self.running:
                    self.check_email()
                    time.sleep(30)  # Check every 30 seconds
                
            except KeyboardInterrupt:
                logger.info("Monitoring stopped by user")
            except Exception as e:
                logger.error(f"Unexpected error in main loop: {e}")
                # Try to restart on unexpected errors
                if self.running:
                    logger.info("Attempting restart due to unexpected error...")
                    self.attempt_restart()
                    # Continue the loop
                    while self.running:
                        try:
                            self.check_email()
                            time.sleep(30)
                        except Exception as e2:
                            logger.error(f"Error after restart: {e2}")
                            time.sleep(60)  # Wait longer on repeated errors
            finally:
                if self.driver:
                    self.driver.quit()
    
    def create_tray_icon(self):
        """Create a simple icon for the system tray"""
        if not TRAY_AVAILABLE:
            return None
        
        # Create a simple 16x16 icon (Windows system tray standard size)
        image = Image.new('RGBA', (16, 16), color=(0, 0, 0, 0))  # Transparent background
        draw = ImageDraw.Draw(image)
        
        # Draw a blue circle background
        draw.ellipse([1, 1, 14, 14], fill='#1877F2', outline='white')  # Facebook blue
        
        # Draw "FB" text
        try:
            # Try to use a small font
            draw.text((3, 2), "FB", fill='white')
        except:
            # Fallback if font issues
            draw.rectangle([3, 3, 5, 12], fill='white')  # F
            draw.rectangle([3, 3, 8, 5], fill='white')
            draw.rectangle([3, 7, 7, 9], fill='white')
            draw.rectangle([9, 3, 12, 5], fill='white')  # B
            draw.rectangle([9, 3, 11, 12], fill='white')
            draw.rectangle([9, 7, 12, 9], fill='white')
            draw.rectangle([9, 10, 12, 12], fill='white')
        
        return image
    
    def start_system_tray(self):
        """Start the system tray icon and monitoring in background"""
        if not TRAY_AVAILABLE:
            logger.error("System tray not available - running without tray")
            # Fallback to regular monitoring
            self.background_monitor()
            return
        
        try:
            logger.info("Starting system tray application...")
            
            # Create tray menu
            menu = pystray.Menu(
                pystray.MenuItem("📧 Email to FB Forwarder", None, enabled=False),
                pystray.MenuItem("📋 Show Log", self.show_log),
                pystray.MenuItem("🔄 Restart", self.restart_app),
                pystray.MenuItem("❌ Quit", self.quit_app)
            )
            
            # Create tray icon
            icon_image = self.create_tray_icon()
            if not icon_image:
                logger.error("Failed to create tray icon")
                self.background_monitor()
                return
            
            self.tray_icon = pystray.Icon(
                name="EmailFBForwarder",
                icon=icon_image,
                title="Email to Facebook Forwarder - Running",
                menu=menu
            )
            
            # Start monitoring in background thread
            monitor_thread = threading.Thread(target=self.background_monitor, daemon=True)
            monitor_thread.start()
            
            logger.info("System tray icon created - should appear in Windows system tray")
            
            # Start tray (this blocks until quit)
            self.tray_icon.run()
            
        except Exception as e:
            logger.error(f"Failed to start system tray: {e}")
            logger.info("Falling back to regular monitoring without tray")
            self.background_monitor()
    
    def background_monitor(self):
        """Background email monitoring for system tray mode"""
        try:
            logger.info("Starting background email monitoring...")
            
            # Start health check thread for tray mode too
            health_thread = threading.Thread(target=self.health_monitor_loop, daemon=True)
            health_thread.start()
            
            while self.running:
                self.check_email()
                time.sleep(30)  # Check every 30 seconds
                
        except KeyboardInterrupt:
            logger.info("Background monitoring stopped by user")
        except Exception as e:
            logger.error(f"Background monitoring error: {e}")
            # Try to restart on errors
            if self.running:
                logger.info("Attempting restart due to background monitoring error...")
                self.attempt_restart()
                # Continue monitoring after restart
                while self.running:
                    try:
                        self.check_email()
                        time.sleep(30)
                    except Exception as e2:
                        logger.error(f"Error after restart: {e2}")
                        time.sleep(60)  # Wait longer on repeated errors
    
    def health_monitor_loop(self):
        """Background health monitoring loop"""
        try:
            while self.running:
                time.sleep(self.health_check_interval)  # Check every minute
                if self.running:
                    self.health_check()
        except Exception as e:
            logger.error(f"Health monitor error: {e}")
    
    def show_log(self, icon, item):
        """Show log file"""
        try:
            os.startfile("forwarder.log")
        except Exception as e:
            logger.error(f"Could not open log file: {e}")
    
    def restart_app(self, icon, item):
        """Restart the application"""
        logger.info("Restarting application...")
        self.quit_app(icon, item)
        os.execv(sys.executable, ['python'] + sys.argv)
    
    def quit_app(self, icon, item):
        """Quit the application"""
        logger.info("Shutting down...")
        self.running = False
        if self.driver:
            self.driver.quit()
        if self.tray_icon:
            self.tray_icon.stop()

def main():
    """Entry point – creates the forwarder object and starts monitoring."""
    parser = argparse.ArgumentParser(description='Email to Facebook Forwarder')
    parser.add_argument('--setup', action='store_true', help='Run initial setup with visible Chrome')
    parser.add_argument('--silent', action='store_true', help='Run silently with system tray')
    args = parser.parse_args()
    
    # Determine mode
    silent_mode = args.silent
    if args.setup:
        print("Running in setup mode with visible Chrome browser...")
        silent_mode = False
    
    forwarder = EmailToFacebookForwarder(silent_mode=silent_mode)
    forwarder.start_monitoring()

# Helper to kill existing Chrome processes so we can reuse the user's profile
def _kill_existing_chrome():
    try:
        if platform.system() == "Windows":
            subprocess.run(["taskkill", "/IM", "chrome.exe", "/F", "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.run(["pkill", "-f", "chrome"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        logger.info("Terminated running Chrome instances to free profile lock")
    except Exception as e:
        logger.warning(f"Unable to terminate Chrome automatically: {e}")

# Process lock to prevent multiple instances
def _acquire_process_lock():
    """Prevent multiple instances of the script from running"""
    lock_file = "email_fb_forwarder.lock"
    try:
        # Try to create a lock file
        with open(lock_file, 'w') as f:
            f.write(str(os.getpid()))
        
        # On Windows, we'll use a simple file-based approach
        # The lock file will be cleaned up when the process exits
        logger.info("Process lock acquired")
        return True
    except Exception as e:
        logger.error(f"Another instance is already running: {e}")
        return False

def _release_process_lock():
    """Release the process lock"""
    lock_file = "email_fb_forwarder.lock"
    try:
        if os.path.exists(lock_file):
            os.remove(lock_file)
            logger.info("Process lock released")
    except Exception as e:
        logger.warning(f"Could not release process lock: {e}")

def signal_handler(signum, frame):
    """Handle shutdown signals gracefully"""
    logger.info(f"Received signal {signum}, shutting down gracefully...")
    # The forwarder instance will be cleaned up in the finally block
    sys.exit(0)

if __name__ == "__main__":
    # Set up signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Register cleanup function
    atexit.register(_release_process_lock)
    
    # Check for existing instances
    if not _acquire_process_lock():
        print("Another instance of Email to Facebook Forwarder is already running!")
        print("Please close the existing instance before starting a new one.")
        sys.exit(1)
    
    try:
        main() 
    finally:
        _release_process_lock() 