# Email to Facebook Forwarder - Deployment Guide

## 📦 **QUICK INSTALLATION**

### **Step 1: Prerequisites**
- **Windows 10/11** (required)
- **Python 3.8+** - Download from [python.org](https://python.org)
  - ⚠️ **IMPORTANT**: Check "Add Python to PATH" during installation
- **Google Chrome** browser (any recent version)

### **Step 2: Download ChromeDriver**
1. Check your Chrome version: `chrome://version/`
2. Download matching ChromeDriver from: [chromedriver.chromium.org](https://chromedriver.chromium.org/)
3. Extract `chromedriver.exe` to the project folder

### **Step 3: Install & Configure**
1. **Run installer**: Double-click `install.bat`
2. **Edit credentials**: Open `.env` file and fill in your details:
   ```
   EMAIL_USER=your-email@gmail.com
   EMAIL_PASSWORD=your-app-password
   EMAIL_HOST=imap.gmail.com
   EMAIL_PORT=993
   FACEBOOK_EMAIL=your-facebook@email.com
   FACEBOOK_PASSWORD=your-facebook-password
   FACEBOOK_GROUP_URL=https://www.messenger.com/t/your-thread-id/
   ```

### **Step 4: First-Time Setup**
1. **Run setup**: Double-click `setup.bat`
2. **Complete login**: Browser will open - complete Facebook login and any 2FA
3. **Verify**: Check that messages appear in your Messenger thread

### **Step 5: Production Use**
- **Recommended**: `run_watchdog.bat` - Maximum reliability with auto-restart
- **Alternative**: `run_silent.bat` - System tray mode only

---

## 🔧 **CONFIGURATION DETAILS**

### **Email Settings**
| Provider | IMAP Host | Port | Notes |
|----------|-----------|------|-------|
| Gmail | `imap.gmail.com` | 993 | Use App Password, not regular password |
| Outlook | `outlook.office365.com` | 993 | Use App Password |
| Yahoo | `imap.mail.yahoo.com` | 993 | Use App Password |
| Zoho | `imap.zoho.com` | 993 | Regular password OK |

### **Facebook Setup**
1. **Get Messenger URL**: 
   - Open your target group/thread in Messenger
   - Copy the URL (looks like: `https://www.messenger.com/t/123456789/`)
2. **Security**: Consider using a dedicated Facebook account for automation

---

## 🚀 **OPERATION MODES**

### **🛡️ High Reliability Mode (Recommended)**
```batch
run_watchdog.bat
```
- **External monitoring** - Restarts forwarder if it crashes
- **Rate limiting** - Prevents spam restarts
- **Emergency alerts** - Notifies when manual intervention needed
- **24/7 operation** - Maximum uptime

### **🔇 System Tray Mode**
```batch
run_silent.bat
```
- **Background operation** - Runs invisibly
- **System tray icon** - Right-click for options
- **Built-in recovery** - Self-healing capabilities

### **👁️ Setup Mode**
```batch
setup.bat
```
- **Visible browser** - For initial login and troubleshooting
- **Manual interaction** - Complete 2FA, checkpoints, etc.

---

## 📊 **MONITORING & LOGS**

### **Log Files**
- `forwarder.log` - Main application log
- `watchdog.log` - Watchdog monitoring log

### **System Tray Menu**
- **Show Log** - Opens log file
- **Restart** - Restart the forwarder
- **Quit** - Stop the application

### **Status Messages**
The forwarder sends status updates to your Messenger thread:
- `DAEMON INIT'd` - Startup notification
- `DAEMON RESTARTED` - Recovery notification
- `🚨 EMERGENCY: DAEMON FAILED` - Manual intervention required

---

## 🔧 **TROUBLESHOOTING**

| Problem | Solution |
|---------|----------|
| **Python not found** | Install Python from python.org, check "Add to PATH" |
| **ChromeDriver errors** | Download correct version matching your Chrome |
| **Email login fails** | Use App Passwords, not regular passwords |
| **Facebook login fails** | Run `setup.bat` to complete 2FA manually |
| **Messages not sending** | Check Messenger URL is correct |
| **Process won't start** | Run `kill_and_restart.bat` to clean up |

### **Emergency Recovery**
```batch
kill_and_restart.bat
```
- Kills all Chrome processes
- Cleans up lock files
- Restarts fresh

---

## 📁 **FILE STRUCTURE**

```
EmailFBForwarder/
├── install.bat              # Main installer
├── setup.bat               # First-time setup
├── run_silent.bat          # System tray mode
├── run_watchdog.bat        # High reliability mode
├── kill_and_restart.bat    # Emergency recovery
├── email_fb_forwarder.py   # Main application
├── watchdog.py             # Monitoring script
├── chromedriver.exe        # Chrome automation driver
├── requirements.txt        # Python dependencies
├── .env                    # Configuration file
├── README.md              # Detailed documentation
└── logs/
    ├── forwarder.log       # Application logs
    └── watchdog.log        # Monitor logs
```

---

## 🎯 **FEATURES**

✅ **Email Monitoring** - IMAP support for all major providers  
✅ **Full Attachments** - Images, documents, all file types  
✅ **Inline Images** - Embedded email images extracted  
✅ **Persistent Login** - Saves Facebook session  
✅ **Auto Recovery** - Self-healing on failures  
✅ **External Monitoring** - Watchdog ensures 24/7 uptime  
✅ **System Tray** - Professional Windows integration  
✅ **Comprehensive Logging** - Full audit trail  
✅ **Rate Limiting** - Prevents Facebook blocks  

---

## 📞 **SUPPORT**

For issues or questions:
1. Check `forwarder.log` for error details
2. Try `kill_and_restart.bat` for recovery
3. Run `setup.bat` if login issues occur
4. Refer to main `README.md` for detailed troubleshooting

**Status**: Production Ready ✅  
**Reliability**: Enterprise Grade 🛡️  
**Maintenance**: Minimal 🔧 